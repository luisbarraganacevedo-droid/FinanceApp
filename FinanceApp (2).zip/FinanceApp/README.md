# FinanceApp — Gestión de Finanzas Personales para Android

## Estructura del proyecto

```
FinanceApp/
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/financeapp/
│       │   ├── data/
│       │   │   ├── db/
│       │   │   │   ├── AppDatabase.kt       ← Room DB + Converters + seed de categorías
│       │   │   │   └── Daos.kt              ← TransactionDao, CategoryDao, CreditDao, CreditPaymentDao
│       │   │   ├── models/
│       │   │   │   └── Models.kt            ← Entidades Room: Transaction, Category, Credit, CreditPayment
│       │   │   └── repository/
│       │   │       └── Repositories.kt      ← TransactionRepo, CategoryRepo, CreditRepo
│       │   ├── notifications/
│       │   │   └── PaymentReminderReceiver.kt  ← AlarmManager + NotificationChannel
│       │   └── ui/
│       │       ├── MainActivity.kt          ← BottomNav + NavController
│       │       ├── ViewModels.kt            ← DashboardVM, TransactionVM, CreditVM, CategoryVM
│       │       ├── dashboard/
│       │       │   └── DashboardFragment.kt ← PieChart + resúmenes
│       │       ├── history/
│       │       │   ├── HistoryFragment.kt   ← Listado con filtros
│       │       │   └── TransactionAdapter.kt
│       │       ├── transactions/
│       │       │   └── AddTransactionActivity.kt
│       │       ├── credits/
│       │       │   └── CreditComponents.kt  ← CreditAdapter + AddCreditActivity + CreditDetailActivity + PaymentAdapter
│       │       └── categories/
│       │           └── ManageCategoriesActivity.kt
│       └── res/
│           ├── layout/          ← XMLs de todas las pantallas
│           ├── menu/            ← Menús de navegación y contexto
│           ├── navigation/      ← nav_graph.xml
│           ├── values/          ← colors, strings, themes
│           ├── drawable/        ← Íconos y shapes
│           └── xml/             ← file_paths.xml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── gradle/wrapper/gradle-wrapper.properties
```

---

## Requisitos previos

| Herramienta          | Versión mínima recomendada |
|----------------------|---------------------------|
| Android Studio       | Ladybug (2024.2.1) o superior |
| JDK                  | 17                        |
| Gradle               | 8.11.1                    |
| Android SDK          | API 36 (Android 16)       |
| Kotlin               | 2.1.0                     |

---

## Pasos para abrir y compilar en Android Studio

### 1. Abrir el proyecto
1. Abre **Android Studio**.
2. Selecciona **File → Open…**
3. Navega a la carpeta `FinanceApp/` y haz clic en **OK**.
4. Android Studio detectará automáticamente el proyecto Gradle.

### 2. Sincronizar dependencias
- Si Android Studio no lo hace automáticamente, haz clic en el banner amarillo **"Sync Now"** o ve a **File → Sync Project with Gradle Files**.
- La primera sincronización puede tardar 3–5 minutos (descarga dependencias: Room, MPAndroidChart, Navigation Component, etc.).

### 3. Agregar el repositorio de JitPack (para MPAndroidChart)
En el archivo **`settings.gradle`** ya incluido, asegúrate de que el bloque `repositories` incluya JitPack:

```gradle
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven { url 'https://jitpack.io' }  // ← AGREGA ESTA LÍNEA si no aparece
    }
}
```

### 4. Seleccionar dispositivo y ejecutar
1. Conecta un dispositivo físico con Android 8.0+ (API 26+) **o** crea un AVD en **Device Manager** con Android 12+ para Android 16.
2. Haz clic en el botón ▶ **Run 'app'** (Shift+F10).

---

## Funcionalidades implementadas

### 🏠 Dashboard (Pantalla de inicio)
- **Balance mensual** en tarjeta destacada con ingresos y gastos del mes actual.
- **Accesos rápidos** para registrar ingreso o gasto directamente.
- **Gráfica de pastel** con gastos del mes por categoría (MPAndroidChart).
- **Resumen anual** de ingresos, gastos y deuda total de créditos.
- **Alerta** de pagos de crédito que vencen en los próximos 7 días.

### 📋 Historial de transacciones
- Lista completa de todas las transacciones ordenadas por fecha.
- **Filtros combinables**: tipo (Ingreso/Gasto), categoría, rango de fechas.
- Totales dinámicos de ingresos y gastos según los filtros activos.
- **Editar** y **eliminar** cada transacción (menú contextual con long-press o botón ⋮).

### ➕ Registro de transacciones
- Formulario con validaciones: monto, descripción obligatoria, fecha, categoría.
- Selector de tipo con pestañas (Gasto / Ingreso) con cambio de color de UI.
- Selector de fecha con DatePickerDialog.
- Campo de notas opcionales.

### 💳 Gestión de créditos
- Lista de créditos activos con monto, tasa de interés y cuotas.
- **Alerta semanal** de pagos próximos a vencer.
- **Detalle del crédito**: cronograma completo, barra de progreso, total de intereses.
- Cada cuota puede marcarse como **pagada/pendiente**.
- **Notificaciones automáticas** (AlarmManager) 3 días antes del vencimiento.
- Cálculo de cuota mensual con fórmula de amortización francesa.

### 📂 Categorías personalizables
- 10 categorías de gasto + 5 de ingreso **predeterminadas** al instalar.
- Crear, editar y eliminar categorías (las predeterminadas no pueden eliminarse).
- Selección de ícono (emoji) y color para cada categoría.

---

## Base de datos (Room)

| Tabla               | Descripción                                    |
|---------------------|------------------------------------------------|
| `transactions`      | Registros de ingresos y gastos                 |
| `categories`        | Categorías con icono, color y tipo             |
| `credits`           | Créditos con monto, tasa y plazos              |
| `credit_payments`   | Cronograma de cuotas por crédito               |

Los datos se almacenan en **SQLite local** mediante Room en `/data/data/com.financeapp/databases/finance_database`.

---

## Permisos requeridos

| Permiso                         | Uso                                          |
|---------------------------------|----------------------------------------------|
| `POST_NOTIFICATIONS`            | Mostrar recordatorios de pago (Android 13+)  |
| `SCHEDULE_EXACT_ALARM`          | Alarmas exactas para recordatorios           |
| `RECEIVE_BOOT_COMPLETED`        | Re-programar alarmas tras reinicio           |

---

## Solución de problemas comunes

**Error: "Could not resolve com.github.PhilJay:MPAndroidChart"**
→ Agrega `maven { url 'https://jitpack.io' }` en `settings.gradle` dentro de `repositories`.

**Error: KSP no encontrado**
→ Verifica que el plugin `com.google.devtools.ksp` esté en `build.gradle` raíz y en `app/build.gradle`.

**La app no muestra notificaciones**
→ En Android 13+, acepta el permiso de notificaciones cuando la app lo solicite al primer inicio.

**Gradle sync falla con "Unsupported class file major version"**
→ Ve a **File → Project Structure → SDK Location** y verifica que el JDK sea versión 17.

---

## Arquitectura

```
UI Layer (Fragments / Activities)
        ↓ observa LiveData
ViewModel Layer (AndroidViewModel + LiveData)
        ↓ llama suspend functions
Repository Layer
        ↓ accede a DAOs
Room Database (SQLite)
```

Patrón: **MVVM** con Repository, LiveData reactivo y corrutinas de Kotlin.
