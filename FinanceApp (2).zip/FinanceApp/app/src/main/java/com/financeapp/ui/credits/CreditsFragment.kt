package com.financeapp.ui.credits

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.financeapp.databinding.FragmentCreditsBinding
import com.financeapp.ui.AppViewModelFactory
import com.financeapp.ui.CreditViewModel

class CreditsFragment : Fragment() {

    private var _binding: FragmentCreditsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: CreditViewModel by viewModels {
        AppViewModelFactory(requireActivity().application)
    }

    private lateinit var creditAdapter: CreditAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCreditsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupFab()
        observeData()
    }

    private fun setupRecyclerView() {
        creditAdapter = CreditAdapter(
            onViewDetails = { credit ->
                val intent = Intent(requireContext(), CreditDetailActivity::class.java)
                intent.putExtra("credit_id", credit.id)
                startActivity(intent)
            },
            onDelete = { credit ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Eliminar crédito")
                    .setMessage("¿Eliminar '${credit.name}' y todos sus pagos?")
                    .setPositiveButton("Eliminar") { _, _ -> viewModel.deleteCredit(credit) }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        )
        binding.recyclerCredits.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerCredits.adapter = creditAdapter
    }

    private fun setupFab() {
        binding.fabAddCredit.setOnClickListener {
            startActivity(Intent(requireContext(), AddCreditActivity::class.java))
        }
    }

    private fun observeData() {
        viewModel.activeCredits.observe(viewLifecycleOwner) { credits ->
            creditAdapter.submitList(credits)
            val hasData = credits.isNotEmpty()
            binding.recyclerCredits.visibility = if (hasData) View.VISIBLE else View.GONE
            binding.tvEmpty.visibility = if (hasData) View.GONE else View.VISIBLE
            binding.tvCreditCount.text = "${credits.size} crédito(s) activo(s)"
        }

        viewModel.getUpcomingPayments(7).observe(viewLifecycleOwner) { payments ->
            if (payments.isNotEmpty()) {
                binding.cardAlerts.visibility = View.VISIBLE
                binding.tvAlertCount.text = "⚠️ ${payments.size} pago(s) vencen esta semana"
            } else {
                binding.cardAlerts.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
