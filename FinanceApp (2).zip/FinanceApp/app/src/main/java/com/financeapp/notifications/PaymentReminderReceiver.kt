package com.financeapp.notifications

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.financeapp.R
import com.financeapp.ui.MainActivity
import java.util.*

class PaymentReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) return

        val creditName = intent.getStringExtra("credit_name") ?: "Crédito"
        val amount = intent.getDoubleExtra("payment_amount", 0.0)
        val paymentId = intent.getLongExtra("payment_id", 0)

        showNotification(context, creditName, amount, paymentId)
    }

    companion object {
        const val CHANNEL_ID = "payment_reminders"
        const val CHANNEL_NAME = "Recordatorios de Pago"

        fun createNotificationChannel(context: Context) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Recordatorios para pagos de créditos"
                enableVibration(true)
            }
            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }

        fun schedulePaymentReminder(
            context: Context,
            paymentId: Long,
            creditName: String,
            amount: Double,
            dueDate: Long,
            daysBefore: Int = 3
        ) {
            val alarmManager = context.getSystemService(AlarmManager::class.java)
            val reminderTime = dueDate - (daysBefore * 24 * 60 * 60 * 1000L)

            if (reminderTime <= System.currentTimeMillis()) return

            val intent = Intent(context, PaymentReminderReceiver::class.java).apply {
                putExtra("payment_id", paymentId)
                putExtra("credit_name", creditName)
                putExtra("payment_amount", amount)
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                paymentId.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime,
                    pendingIntent
                )
            } catch (e: SecurityException) {
                alarmManager.set(AlarmManager.RTC_WAKEUP, reminderTime, pendingIntent)
            }
        }

        fun cancelPaymentReminder(context: Context, paymentId: Long) {
            val alarmManager = context.getSystemService(AlarmManager::class.java)
            val intent = Intent(context, PaymentReminderReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                paymentId.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }

        private fun showNotification(context: Context, creditName: String, amount: Double, paymentId: Long) {
            val mainIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("navigate_to", "credits")
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 0, mainIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val formattedAmount = String.format("$%.2f", amount)
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("⚠️ Pago próximo: $creditName")
                .setContentText("Cuota de $formattedAmount vence en 3 días")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.notify(paymentId.toInt(), notification)
        }
    }
}
