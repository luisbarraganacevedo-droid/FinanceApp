package com.financeapp.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.*
import com.financeapp.data.db.AppDatabase
import com.financeapp.data.models.*
import com.financeapp.data.repository.*
import com.financeapp.notifications.PaymentReminderReceiver
import com.financeapp.utils.DateUtils
import kotlinx.coroutines.launch
import java.util.Calendar

// -------- Dashboard ViewModel --------
class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val transactionRepo = TransactionRepository(db.transactionDao())
    private val creditRepo = CreditRepository(db.creditDao(), db.creditPaymentDao())

    private val _monthlyIncome = MutableLiveData<Double>()
    val monthlyIncome: LiveData<Double> = _monthlyIncome

    private val _monthlyExpense = MutableLiveData<Double>()
    val monthlyExpense: LiveData<Double> = _monthlyExpense

    private val _yearlyIncome = MutableLiveData<Double>()
    val yearlyIncome: LiveData<Double> = _yearlyIncome

    private val _yearlyExpense = MutableLiveData<Double>()
    val yearlyExpense: LiveData<Double> = _yearlyExpense

    private val _totalDebt = MutableLiveData<Double>()
    val totalDebt: LiveData<Double> = _totalDebt

    private val _categoryExpenses = MutableLiveData<List<CategorySummary>>()
    val categoryExpenses: LiveData<List<CategorySummary>> = _categoryExpenses

    val upcomingPayments: LiveData<List<CreditPayment>> = creditRepo.getUpcomingPayments(
        System.currentTimeMillis(),
        System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000)
    )

    fun loadData() {
        viewModelScope.launch {
            val monthStart = DateUtils.getStartOfMonth()
            val monthEnd = DateUtils.getEndOfMonth()
            val yearStart = DateUtils.getStartOfYear()
            val yearEnd = DateUtils.getEndOfYear()

            _monthlyIncome.value = transactionRepo.getTotalIncome(monthStart, monthEnd)
            _monthlyExpense.value = transactionRepo.getTotalExpense(monthStart, monthEnd)
            _yearlyIncome.value = transactionRepo.getTotalIncome(yearStart, yearEnd)
            _yearlyExpense.value = transactionRepo.getTotalExpense(yearStart, yearEnd)
            _totalDebt.value = creditRepo.getTotalCreditDebt()
            _categoryExpenses.value = transactionRepo.getExpensesByCategory(monthStart, monthEnd)
        }
    }

    init { loadData() }
}

// -------- Transaction ViewModel --------
class TransactionViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val transactionRepo = TransactionRepository(db.transactionDao())
    private val categoryRepo = CategoryRepository(db.categoryDao())

    val allTransactions = transactionRepo.getAllTransactions()
    val allCategories = categoryRepo.getAllCategories()

    fun getFilteredTransactions(
        type: String? = null,
        categoryId: Long? = null,
        startDate: Long? = null,
        endDate: Long? = null
    ) = transactionRepo.getFilteredTransactions(type, categoryId, startDate, endDate)

    fun getCategoriesByType(type: TransactionType) = categoryRepo.getCategoriesByType(type)

    suspend fun insert(transaction: Transaction): Long = transactionRepo.insert(transaction)
    suspend fun update(transaction: Transaction) = transactionRepo.update(transaction)
    suspend fun delete(transaction: Transaction) = transactionRepo.delete(transaction)
    suspend fun getById(id: Long): Transaction? = transactionRepo.getById(id)
}

// -------- Credit ViewModel --------
class CreditViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val creditRepo = CreditRepository(db.creditDao(), db.creditPaymentDao())

    val activeCredits = creditRepo.getActiveCredits()
    val allCredits = creditRepo.getAllCredits()
    val allPendingPayments = creditRepo.getAllPendingPayments()

    fun getPaymentsForCredit(creditId: Long) = creditRepo.getPaymentsForCredit(creditId)

    fun getUpcomingPayments(days: Int): LiveData<List<CreditPayment>> {
        val now = System.currentTimeMillis()
        val end = now + (days.toLong() * 24 * 60 * 60 * 1000)
        return creditRepo.getUpcomingPayments(now, end)
    }

    /** Inserts credit + schedule + schedules notifications. Call from Activity with appContext. */
    fun insertCreditWithPaymentsAndNotify(credit: Credit, appContext: Context) {
        viewModelScope.launch {
            val creditId = creditRepo.insert(credit)
            val creditWithId = credit.copy(id = creditId)
            val payments = generatePaymentSchedule(creditId, creditWithId)
            creditRepo.insertPayments(payments)

            // Schedule notifications for the first 3 upcoming unpaid payments
            payments.take(3).forEachIndexed { _, payment ->
                PaymentReminderReceiver.schedulePaymentReminder(
                    appContext, payment.id, credit.name, payment.amount, payment.dueDate
                )
            }
        }
    }

    fun updateCredit(credit: Credit) = viewModelScope.launch { creditRepo.update(credit) }

    fun deleteCredit(credit: Credit) = viewModelScope.launch { creditRepo.delete(credit) }

    fun markPaymentAsPaid(payment: CreditPayment) = viewModelScope.launch {
        creditRepo.updatePayment(payment.copy(isPaid = true, paidDate = System.currentTimeMillis()))
    }

    fun markPaymentAsUnpaid(payment: CreditPayment) = viewModelScope.launch {
        creditRepo.updatePayment(payment.copy(isPaid = false, paidDate = null))
    }

    suspend fun getCreditById(id: Long): Credit? = creditRepo.getCreditById(id)
    suspend fun getPaymentById(id: Long): CreditPayment? = creditRepo.getPaymentById(id)

    fun calculateMonthlyPayment(totalAmount: Double, interestRate: Double, installments: Int): Double {
        if (interestRate == 0.0) return totalAmount / installments
        val monthlyRate = interestRate / 100.0 / 12.0
        val pow = Math.pow(1 + monthlyRate, installments.toDouble())
        return totalAmount * monthlyRate * pow / (pow - 1)
    }

    fun generatePaymentSchedule(creditId: Long, credit: Credit): List<CreditPayment> {
        val payments = mutableListOf<CreditPayment>()
        val monthlyPayment = calculateMonthlyPayment(
            credit.totalAmount, credit.interestRate, credit.numberOfInstallments
        )
        for (i in 1..credit.numberOfInstallments) {
            val baseDue = DateUtils.addMonths(credit.startDate, i)
            val cal = Calendar.getInstance()
            cal.timeInMillis = baseDue
            cal.set(
                Calendar.DAY_OF_MONTH,
                minOf(credit.paymentDayOfMonth, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
            )
            payments.add(
                CreditPayment(
                    creditId = creditId,
                    installmentNumber = i,
                    dueDate = cal.timeInMillis,
                    amount = monthlyPayment
                )
            )
        }
        return payments
    }
}

// -------- Category ViewModel --------
class CategoryViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val categoryRepo = CategoryRepository(db.categoryDao())

    val allCategories = categoryRepo.getAllCategories()
    fun getCategoriesByType(type: TransactionType) = categoryRepo.getCategoriesByType(type)

    fun insert(category: Category) = viewModelScope.launch { categoryRepo.insert(category) }
    fun update(category: Category) = viewModelScope.launch { categoryRepo.update(category) }
    fun delete(category: Category) = viewModelScope.launch { categoryRepo.delete(category) }
}

// -------- ViewModelFactory --------
class AppViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(DashboardViewModel::class.java) ->
                DashboardViewModel(application) as T
            modelClass.isAssignableFrom(TransactionViewModel::class.java) ->
                TransactionViewModel(application) as T
            modelClass.isAssignableFrom(CreditViewModel::class.java) ->
                CreditViewModel(application) as T
            modelClass.isAssignableFrom(CategoryViewModel::class.java) ->
                CategoryViewModel(application) as T
            else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
        }
    }
}
