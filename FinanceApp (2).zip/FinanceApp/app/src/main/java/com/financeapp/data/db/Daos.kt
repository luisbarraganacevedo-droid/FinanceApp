package com.financeapp.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.financeapp.data.models.*

@Dao
interface TransactionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: Transaction): Long

    @Update
    suspend fun update(transaction: Transaction)

    @Delete
    suspend fun delete(transaction: Transaction)

    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun getAllTransactions(): LiveData<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getTransactionById(id: Long): Transaction?

    @Query("""
        SELECT * FROM transactions 
        WHERE (:type IS NULL OR type = :type)
        AND (:categoryId IS NULL OR categoryId = :categoryId)
        AND (:startDate IS NULL OR date >= :startDate)
        AND (:endDate IS NULL OR date <= :endDate)
        ORDER BY date DESC
    """)
    fun getFilteredTransactions(
        type: String?,
        categoryId: Long?,
        startDate: Long?,
        endDate: Long?
    ): LiveData<List<Transaction>>

    @Query("""
        SELECT SUM(amount) FROM transactions 
        WHERE type = 'INCOME' 
        AND date >= :startDate AND date <= :endDate
    """)
    suspend fun getTotalIncome(startDate: Long, endDate: Long): Double?

    @Query("""
        SELECT SUM(amount) FROM transactions 
        WHERE type = 'EXPENSE' 
        AND date >= :startDate AND date <= :endDate
    """)
    suspend fun getTotalExpense(startDate: Long, endDate: Long): Double?

    @Query("""
        SELECT t.categoryId, c.name as categoryName, c.color as categoryColor, 
               c.icon as categoryIcon, SUM(t.amount) as totalAmount, COUNT(t.id) as transactionCount
        FROM transactions t
        LEFT JOIN categories c ON t.categoryId = c.id
        WHERE t.type = 'EXPENSE'
        AND t.date >= :startDate AND t.date <= :endDate
        GROUP BY t.categoryId
        ORDER BY totalAmount DESC
    """)
    suspend fun getExpensesByCategory(startDate: Long, endDate: Long): List<CategorySummary>

    @Query("""
        SELECT * FROM transactions 
        WHERE date >= :startDate AND date <= :endDate
        ORDER BY date DESC
    """)
    fun getTransactionsByDateRange(startDate: Long, endDate: Long): LiveData<List<Transaction>>
}

@Dao
interface CategoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: Category): Long

    @Update
    suspend fun update(category: Category)

    @Delete
    suspend fun delete(category: Category)

    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategories(): LiveData<List<Category>>

    @Query("SELECT * FROM categories WHERE type = :type ORDER BY name ASC")
    fun getCategoriesByType(type: String): LiveData<List<Category>>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getCategoryById(id: Long): Category?

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun getCategoryCount(): Int
}

@Dao
interface CreditDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(credit: Credit): Long

    @Update
    suspend fun update(credit: Credit)

    @Delete
    suspend fun delete(credit: Credit)

    @Query("SELECT * FROM credits WHERE isActive = 1 ORDER BY startDate DESC")
    fun getActiveCredits(): LiveData<List<Credit>>

    @Query("SELECT * FROM credits ORDER BY startDate DESC")
    fun getAllCredits(): LiveData<List<Credit>>

    @Query("SELECT * FROM credits WHERE id = :id")
    suspend fun getCreditById(id: Long): Credit?

    @Query("SELECT SUM(totalAmount) FROM credits WHERE isActive = 1")
    suspend fun getTotalCreditDebt(): Double?
}

@Dao
interface CreditPaymentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(payment: CreditPayment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(payments: List<CreditPayment>)

    @Update
    suspend fun update(payment: CreditPayment)

    @Delete
    suspend fun delete(payment: CreditPayment)

    @Query("SELECT * FROM credit_payments WHERE creditId = :creditId ORDER BY installmentNumber ASC")
    fun getPaymentsForCredit(creditId: Long): LiveData<List<CreditPayment>>

    @Query("""
        SELECT * FROM credit_payments 
        WHERE isPaid = 0 
        AND dueDate >= :startDate AND dueDate <= :endDate
        ORDER BY dueDate ASC
    """)
    fun getUpcomingPayments(startDate: Long, endDate: Long): LiveData<List<CreditPayment>>

    @Query("""
        SELECT * FROM credit_payments 
        WHERE isPaid = 0 
        ORDER BY dueDate ASC
    """)
    fun getAllPendingPayments(): LiveData<List<CreditPayment>>

    @Query("DELETE FROM credit_payments WHERE creditId = :creditId")
    suspend fun deletePaymentsForCredit(creditId: Long)

    @Query("SELECT * FROM credit_payments WHERE id = :id")
    suspend fun getPaymentById(id: Long): CreditPayment?
}
