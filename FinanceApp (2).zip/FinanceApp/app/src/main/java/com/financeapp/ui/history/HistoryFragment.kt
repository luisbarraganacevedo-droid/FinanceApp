package com.financeapp.ui.history

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.financeapp.data.models.Category
import com.financeapp.data.models.Transaction
import com.financeapp.databinding.FragmentHistoryBinding
import com.financeapp.ui.AppViewModelFactory
import com.financeapp.ui.TransactionViewModel
import com.financeapp.ui.transactions.AddTransactionActivity
import com.financeapp.utils.CurrencyFormatter
import com.financeapp.utils.DateUtils
import kotlinx.coroutines.launch
import java.util.Calendar

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TransactionViewModel by viewModels {
        AppViewModelFactory(requireActivity().application)
    }

    private lateinit var adapter: TransactionAdapter
    private var allCategories = listOf<Category>()
    private var filterType: String? = null
    private var filterCategoryId: Long? = null
    private var filterStartDate: Long? = null
    private var filterEndDate: Long? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupFilters()
        observeData()
    }

    private fun setupRecyclerView() {
        adapter = TransactionAdapter(
            onEdit = { transaction ->
                val intent = Intent(requireContext(), AddTransactionActivity::class.java)
                intent.putExtra("transaction_id", transaction.id)
                startActivity(intent)
            },
            onDelete = { transaction -> confirmDelete(transaction) },
            getCategoryById = { id -> allCategories.find { it.id == id } }
        )
        binding.recyclerTransactions.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerTransactions.adapter = adapter
    }

    private fun setupFilters() {
        binding.chipAll.setOnClickListener { filterType = null; applyFilters() }
        binding.chipIncome.setOnClickListener { filterType = "INCOME"; applyFilters() }
        binding.chipExpense.setOnClickListener { filterType = "EXPENSE"; applyFilters() }

        binding.btnFilterDate.setOnClickListener { showDateFilterDialog() }

        binding.btnFilterCategory.setOnClickListener {
            val names = listOf("Todas") + allCategories.map { "${it.icon} ${it.name}" }
            AlertDialog.Builder(requireContext())
                .setTitle("Filtrar por categoría")
                .setItems(names.toTypedArray()) { _, which ->
                    filterCategoryId = if (which == 0) null else allCategories[which - 1].id
                    applyFilters()
                }
                .show()
        }

        binding.btnClearFilters.setOnClickListener {
            filterType = null
            filterCategoryId = null
            filterStartDate = null
            filterEndDate = null
            binding.chipAll.isChecked = true
            binding.tvFilterDateRange.visibility = View.GONE
            applyFilters()
        }
    }

    private fun showDateFilterDialog() {
        val cal = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, startYear, startMonth, startDay ->
            val startCal = Calendar.getInstance()
            startCal.set(startYear, startMonth, startDay)
            filterStartDate = DateUtils.getStartOfDay(startCal.timeInMillis)

            DatePickerDialog(requireContext(), { _, endYear, endMonth, endDay ->
                val endCal = Calendar.getInstance()
                endCal.set(endYear, endMonth, endDay)
                filterEndDate = DateUtils.getEndOfDay(endCal.timeInMillis)

                binding.tvFilterDateRange.visibility = View.VISIBLE
                binding.tvFilterDateRange.text =
                    "Desde: ${DateUtils.formatDate(filterStartDate!!)} - Hasta: ${DateUtils.formatDate(filterEndDate!!)}"
                applyFilters()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()

        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun applyFilters() {
        viewModel.getFilteredTransactions(
            filterType, filterCategoryId, filterStartDate, filterEndDate
        ).observe(viewLifecycleOwner) { transactions ->
            updateTransactionList(transactions)
        }
    }

    private fun observeData() {
        viewModel.allCategories.observe(viewLifecycleOwner) { cats ->
            allCategories = cats
        }
        viewModel.allTransactions.observe(viewLifecycleOwner) { transactions ->
            updateTransactionList(transactions)
        }
    }

    private fun updateTransactionList(transactions: List<Transaction>) {
        adapter.submitList(transactions)
        val hasData = transactions.isNotEmpty()
        binding.recyclerTransactions.visibility = if (hasData) View.VISIBLE else View.GONE
        binding.tvEmpty.visibility = if (hasData) View.GONE else View.VISIBLE

        val totalIncome = transactions.filter { it.type.name == "INCOME" }.sumOf { it.amount }
        val totalExpense = transactions.filter { it.type.name == "EXPENSE" }.sumOf { it.amount }
        binding.tvSummaryIncome.text = CurrencyFormatter.format(totalIncome)
        binding.tvSummaryExpense.text = CurrencyFormatter.format(totalExpense)
        binding.tvTransactionCount.text = "${transactions.size} transacciones"
    }

    private fun confirmDelete(transaction: Transaction) {
        AlertDialog.Builder(requireContext())
            .setTitle("Eliminar registro")
            .setMessage("¿Estás seguro de eliminar este registro?")
            .setPositiveButton("Eliminar") { _, _ ->
                lifecycleScope.launch {
                    viewModel.delete(transaction)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        applyFilters()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
