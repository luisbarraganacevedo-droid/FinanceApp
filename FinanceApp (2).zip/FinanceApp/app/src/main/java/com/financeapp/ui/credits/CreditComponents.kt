package com.financeapp.ui.credits

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.*
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.financeapp.R
import com.financeapp.data.models.Credit
import com.financeapp.data.models.CreditPayment
import com.financeapp.databinding.ActivityAddCreditBinding
import com.financeapp.databinding.ActivityCreditDetailBinding
import com.financeapp.databinding.ItemCreditBinding
import com.financeapp.databinding.ItemPaymentBinding
import com.financeapp.notifications.PaymentReminderReceiver
import com.financeapp.ui.AppViewModelFactory
import com.financeapp.ui.CreditViewModel
import com.financeapp.utils.CurrencyFormatter
import com.financeapp.utils.DateUtils
import com.financeapp.utils.ValidationUtils
import kotlinx.coroutines.launch
import java.util.Calendar

// -------- Credit Adapter --------
class CreditAdapter(
    private val onViewDetails: (Credit) -> Unit,
    private val onDelete: (Credit) -> Unit
) : ListAdapter<Credit, CreditAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemCreditBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemCreditBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(credit: Credit) {
            binding.tvCreditName.text = credit.name
            binding.tvTotalAmount.text = CurrencyFormatter.format(credit.totalAmount)
            binding.tvInterestRate.text = "${credit.interestRate}% anual"
            binding.tvInstallments.text = "${credit.numberOfInstallments} cuotas"
            binding.tvStartDate.text = "Inicio: ${DateUtils.formatDate(credit.startDate)}"
            binding.chipActive.visibility = if (credit.isActive) View.VISIBLE else View.GONE

            binding.root.setOnClickListener { onViewDetails(credit) }
            binding.btnMore.setOnClickListener { view ->
                PopupMenu(binding.root.context, view).apply {
                    inflate(R.menu.credit_context_menu)
                    setOnMenuItemClickListener { item ->
                        when (item.itemId) {
                            R.id.action_view -> { onViewDetails(credit); true }
                            R.id.action_delete -> { onDelete(credit); true }
                            else -> false
                        }
                    }
                    show()
                }
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Credit>() {
        override fun areItemsTheSame(a: Credit, b: Credit) = a.id == b.id
        override fun areContentsTheSame(a: Credit, b: Credit) = a == b
    }
}

// -------- Add Credit Activity --------
class AddCreditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddCreditBinding
    private val viewModel: CreditViewModel by viewModels { AppViewModelFactory(application) }
    private var selectedStartDate = System.currentTimeMillis()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddCreditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Nuevo Crédito"

        setupDatePicker()
        setupSaveButton()

        val watcher = createWatcher { updateMonthlyPaymentPreview() }
        binding.etTotalAmount.addTextChangedListener(watcher)
        binding.etInterestRate.addTextChangedListener(watcher)
        binding.etInstallments.addTextChangedListener(watcher)
    }

    private fun setupDatePicker() {
        binding.btnSelectDate.text = DateUtils.formatDateFull(selectedStartDate)
        binding.btnSelectDate.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                cal.set(y, m, d)
                selectedStartDate = cal.timeInMillis
                binding.btnSelectDate.text = DateUtils.formatDateFull(selectedStartDate)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener {
            if (validateForm()) saveCredit()
        }
    }

    private fun validateForm(): Boolean {
        var valid = true
        if (binding.etCreditName.text.isNullOrBlank()) {
            binding.tilCreditName.error = "El nombre es requerido"; valid = false
        } else binding.tilCreditName.error = null

        if (!ValidationUtils.isValidAmount(binding.etTotalAmount.text.toString())) {
            binding.tilTotalAmount.error = "Monto inválido"; valid = false
        } else binding.tilTotalAmount.error = null

        if (!ValidationUtils.isValidInterestRate(binding.etInterestRate.text.toString())) {
            binding.tilInterestRate.error = "Tasa inválida (0-100)"; valid = false
        } else binding.tilInterestRate.error = null

        if (!ValidationUtils.isValidInstallments(binding.etInstallments.text.toString())) {
            binding.tilInstallments.error = "Número de cuotas inválido"; valid = false
        } else binding.tilInstallments.error = null

        val payDay = binding.etPaymentDay.text.toString().toIntOrNull()
        if (payDay == null || payDay < 1 || payDay > 31) {
            binding.tilPaymentDay.error = "Día inválido (1-31)"; valid = false
        } else binding.tilPaymentDay.error = null

        return valid
    }

    private fun saveCredit() {
        val credit = Credit(
            name = binding.etCreditName.text.toString().trim(),
            totalAmount = binding.etTotalAmount.text.toString().toDouble(),
            interestRate = binding.etInterestRate.text.toString().toDouble(),
            startDate = selectedStartDate,
            numberOfInstallments = binding.etInstallments.text.toString().toInt(),
            paymentDayOfMonth = binding.etPaymentDay.text.toString().toInt(),
            notes = binding.etNotes.text.toString().trim()
        )

        viewModel.insertCreditWithPaymentsAndNotify(credit, applicationContext)
        Toast.makeText(this, "Crédito guardado", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun updateMonthlyPaymentPreview() {
        val amount = binding.etTotalAmount.text.toString().toDoubleOrNull() ?: return
        val rate = binding.etInterestRate.text.toString().toDoubleOrNull() ?: return
        val installments = binding.etInstallments.text.toString().toIntOrNull() ?: return
        if (amount > 0 && rate >= 0 && installments > 0) {
            val monthly = viewModel.calculateMonthlyPayment(amount, rate, installments)
            binding.tvMonthlyPreview.text = "Cuota mensual estimada: ${CurrencyFormatter.format(monthly)}"
            binding.tvMonthlyPreview.visibility = View.VISIBLE
        }
    }

    private fun createWatcher(action: () -> Unit) = object : android.text.TextWatcher {
        override fun afterTextChanged(s: android.text.Editable?) = action()
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

// -------- Credit Detail Activity --------
class CreditDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreditDetailBinding
    private val viewModel: CreditViewModel by viewModels { AppViewModelFactory(application) }
    private var creditId: Long = -1
    private lateinit var paymentAdapter: PaymentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreditDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        creditId = intent.getLongExtra("credit_id", -1)
        if (creditId == -1L) { finish(); return }

        setupRecyclerView()
        loadCreditData()
    }

    private fun setupRecyclerView() {
        paymentAdapter = PaymentAdapter(
            onMarkPaid = { payment ->
                viewModel.markPaymentAsPaid(payment)
                PaymentReminderReceiver.cancelPaymentReminder(applicationContext, payment.id)
            },
            onMarkUnpaid = { payment -> viewModel.markPaymentAsUnpaid(payment) }
        )
        binding.recyclerPayments.layoutManager = LinearLayoutManager(this)
        binding.recyclerPayments.adapter = paymentAdapter
    }

    private fun loadCreditData() {
        lifecycleScope.launch {
            val credit = viewModel.getCreditById(creditId) ?: return@launch
            supportActionBar?.title = credit.name
            binding.tvCreditName.text = credit.name
            binding.tvTotalAmount.text = CurrencyFormatter.format(credit.totalAmount)
            binding.tvInterestRate.text = "${credit.interestRate}% anual"
            binding.tvInstallments.text = "${credit.numberOfInstallments} cuotas"
            binding.tvStartDate.text = DateUtils.formatDate(credit.startDate)
            binding.tvNotes.text = credit.notes.ifEmpty { "Sin notas" }

            val monthly = viewModel.calculateMonthlyPayment(
                credit.totalAmount, credit.interestRate, credit.numberOfInstallments
            )
            binding.tvMonthlyPayment.text = CurrencyFormatter.format(monthly)
            val totalToPay = monthly * credit.numberOfInstallments
            binding.tvTotalToPay.text = CurrencyFormatter.format(totalToPay)
            binding.tvTotalInterest.text = CurrencyFormatter.format(totalToPay - credit.totalAmount)
        }

        viewModel.getPaymentsForCredit(creditId).observe(this) { payments ->
            paymentAdapter.submitList(payments)
            val paid = payments.count { it.isPaid }
            val total = payments.size
            binding.tvProgress.text = "$paid de $total pagos realizados"
            binding.progressBar.max = total
            binding.progressBar.progress = paid
            val pendingAmount = payments.filter { !it.isPaid }.sumOf { it.amount }
            binding.tvPendingAmount.text = CurrencyFormatter.format(pendingAmount)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

// -------- Payment Adapter --------
class PaymentAdapter(
    private val onMarkPaid: (CreditPayment) -> Unit,
    private val onMarkUnpaid: (CreditPayment) -> Unit
) : ListAdapter<CreditPayment, PaymentAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPaymentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemPaymentBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(payment: CreditPayment) {
            binding.tvInstallmentNumber.text = "Cuota #${payment.installmentNumber}"
            binding.tvDueDate.text = "Vence: ${DateUtils.formatDate(payment.dueDate)}"
            binding.tvAmount.text = CurrencyFormatter.format(payment.amount)

            val now = System.currentTimeMillis()
            val isOverdue = !payment.isPaid && payment.dueDate < now

            when {
                payment.isPaid -> {
                    binding.chipStatus.text = "✅ Pagada"
                    binding.chipStatus.setChipBackgroundColorResource(R.color.income_green)
                    payment.paidDate?.let {
                        binding.tvPaidDate.text = "Pagada: ${DateUtils.formatDate(it)}"
                    }
                    binding.tvPaidDate.visibility = View.VISIBLE
                    binding.btnMarkPaid.text = "Marcar pendiente"
                    binding.btnMarkPaid.setOnClickListener { onMarkUnpaid(payment) }
                }
                isOverdue -> {
                    binding.chipStatus.text = "⚠️ Vencida"
                    binding.chipStatus.setChipBackgroundColorResource(R.color.expense_red)
                    binding.tvPaidDate.visibility = View.GONE
                    binding.btnMarkPaid.text = "Marcar pagada"
                    binding.btnMarkPaid.setOnClickListener { onMarkPaid(payment) }
                }
                else -> {
                    val daysLeft = DateUtils.getDaysDifference(now, payment.dueDate)
                    binding.chipStatus.text = "⏰ $daysLeft días"
                    binding.chipStatus.setChipBackgroundColorResource(R.color.primary_color)
                    binding.tvPaidDate.visibility = View.GONE
                    binding.btnMarkPaid.text = "Marcar pagada"
                    binding.btnMarkPaid.setOnClickListener { onMarkPaid(payment) }
                }
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<CreditPayment>() {
        override fun areItemsTheSame(a: CreditPayment, b: CreditPayment) = a.id == b.id
        override fun areContentsTheSame(a: CreditPayment, b: CreditPayment) = a == b
    }
}
