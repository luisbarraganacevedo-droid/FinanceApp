package com.financeapp.ui.dashboard

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.financeapp.R
import com.financeapp.data.models.CategorySummary
import com.financeapp.databinding.FragmentDashboardBinding
import com.financeapp.ui.AppViewModelFactory
import com.financeapp.ui.DashboardViewModel
import com.financeapp.ui.transactions.AddTransactionActivity
import com.financeapp.utils.CurrencyFormatter
import com.financeapp.utils.DateUtils
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.PercentFormatter

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DashboardViewModel by viewModels {
        AppViewModelFactory(requireActivity().application)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
        setupChart()
        observeData()
    }

    private fun setupClickListeners() {
        binding.fabAddTransaction.setOnClickListener {
            startActivity(Intent(requireContext(), AddTransactionActivity::class.java))
        }
        binding.cardAddIncome.setOnClickListener {
            val intent = Intent(requireContext(), AddTransactionActivity::class.java)
            intent.putExtra("type", "INCOME")
            startActivity(intent)
        }
        binding.cardAddExpense.setOnClickListener {
            val intent = Intent(requireContext(), AddTransactionActivity::class.java)
            intent.putExtra("type", "EXPENSE")
            startActivity(intent)
        }
    }

    private fun setupChart() {
        binding.pieChart.apply {
            description.isEnabled = false
            isDrawHoleEnabled = true
            holeRadius = 55f
            transparentCircleRadius = 60f
            setUsePercentValues(true)
            setDrawEntryLabels(false)
            legend.isEnabled = true
            legend.textSize = 11f
            setNoDataText("Sin datos este mes")
            setNoDataTextColor(Color.GRAY)
        }
    }

    private fun observeData() {
        binding.tvMonthTitle.text = DateUtils.formatMonthYear(System.currentTimeMillis())
            .replaceFirstChar { it.uppercase() }

        viewModel.monthlyIncome.observe(viewLifecycleOwner) { income ->
            binding.tvMonthlyIncome.text = CurrencyFormatter.format(income ?: 0.0)
            updateBalance()
        }
        viewModel.monthlyExpense.observe(viewLifecycleOwner) { expense ->
            binding.tvMonthlyExpense.text = CurrencyFormatter.format(expense ?: 0.0)
            updateBalance()
        }
        viewModel.yearlyIncome.observe(viewLifecycleOwner) { income ->
            binding.tvYearlyIncome.text = CurrencyFormatter.format(income ?: 0.0)
        }
        viewModel.yearlyExpense.observe(viewLifecycleOwner) { expense ->
            binding.tvYearlyExpense.text = CurrencyFormatter.format(expense ?: 0.0)
        }
        viewModel.totalDebt.observe(viewLifecycleOwner) { debt ->
            binding.tvTotalDebt.text = CurrencyFormatter.format(debt ?: 0.0)
        }
        viewModel.categoryExpenses.observe(viewLifecycleOwner) { categories ->
            updatePieChart(categories ?: emptyList())
        }
        viewModel.upcomingPayments.observe(viewLifecycleOwner) { payments ->
            if (payments.isNullOrEmpty()) {
                binding.cardUpcomingPayments.visibility = View.GONE
            } else {
                binding.cardUpcomingPayments.visibility = View.VISIBLE
                binding.tvUpcomingCount.text = "⚠️ ${payments.size} pago(s) vencen esta semana"
            }
        }
    }

    private fun updateBalance() {
        val income = viewModel.monthlyIncome.value ?: 0.0
        val expense = viewModel.monthlyExpense.value ?: 0.0
        val balance = income - expense
        binding.tvMonthlyBalance.text = CurrencyFormatter.format(balance)
        binding.tvMonthlyBalance.setTextColor(
            if (balance >= 0) requireContext().getColor(R.color.income_green)
            else requireContext().getColor(R.color.expense_red)
        )
    }

    private fun updatePieChart(categories: List<CategorySummary>) {
        if (categories.isEmpty()) {
            binding.pieChart.clear()
            binding.pieChart.invalidate()
            return
        }
        val entries = categories.map { PieEntry(it.totalAmount.toFloat(), it.categoryName) }
        val colors = categories.map {
            try { Color.parseColor(it.categoryColor) } catch (e: Exception) { Color.GRAY }
        }
        val dataSet = PieDataSet(entries, "").apply {
            this.colors = colors
            sliceSpace = 3f
            selectionShift = 8f
            valueFormatter = PercentFormatter(binding.pieChart)
            valueTextSize = 10f
            valueTextColor = Color.WHITE
        }
        binding.pieChart.data = PieData(dataSet)
        binding.pieChart.animateY(800)
        binding.pieChart.invalidate()
    }

    override fun onResume() {
        super.onResume()
        viewModel.loadData()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
