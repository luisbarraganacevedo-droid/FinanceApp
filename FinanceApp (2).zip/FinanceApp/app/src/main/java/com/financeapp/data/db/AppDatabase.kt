package com.financeapp.data.db

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.financeapp.data.models.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@TypeConverters(Converters::class)
@Database(
    entities = [Transaction::class, Category::class, Credit::class, CreditPayment::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun creditDao(): CreditDao
    abstract fun creditPaymentDao(): CreditPaymentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "finance_database"
                )
                    .addCallback(DatabaseCallback(context))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    populateDefaultCategories(database.categoryDao())
                }
            }
        }

        suspend fun populateDefaultCategories(categoryDao: CategoryDao) {
            val defaultExpenseCategories = listOf(
                Category(name = "Alimentación", icon = "🍔", color = "#FF6B6B", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Transporte", icon = "🚗", color = "#4ECDC4", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Servicios", icon = "💡", color = "#45B7D1", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Salud", icon = "🏥", color = "#96CEB4", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Educación", icon = "📚", color = "#FFEAA7", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Entretenimiento", icon = "🎮", color = "#DDA0DD", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Ropa", icon = "👕", color = "#F0E68C", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Hogar", icon = "🏠", color = "#98FB98", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Tecnología", icon = "💻", color = "#87CEEB", type = TransactionType.EXPENSE, isDefault = true),
                Category(name = "Otros Gastos", icon = "📦", color = "#D3D3D3", type = TransactionType.EXPENSE, isDefault = true)
            )
            val defaultIncomeCategories = listOf(
                Category(name = "Salario", icon = "💼", color = "#2ECC71", type = TransactionType.INCOME, isDefault = true),
                Category(name = "Freelance", icon = "💻", color = "#27AE60", type = TransactionType.INCOME, isDefault = true),
                Category(name = "Inversiones", icon = "📈", color = "#16A085", type = TransactionType.INCOME, isDefault = true),
                Category(name = "Ventas", icon = "🏪", color = "#1ABC9C", type = TransactionType.INCOME, isDefault = true),
                Category(name = "Otros Ingresos", icon = "💰", color = "#2980B9", type = TransactionType.INCOME, isDefault = true)
            )
            defaultExpenseCategories.forEach { categoryDao.insert(it) }
            defaultIncomeCategories.forEach { categoryDao.insert(it) }
        }
    }
}

class Converters {
    @TypeConverter
    fun fromTransactionType(type: TransactionType): String = type.name

    @TypeConverter
    fun toTransactionType(value: String): TransactionType = TransactionType.valueOf(value)
}
