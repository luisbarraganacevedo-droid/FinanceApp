package com.financeapp.ui.transactions

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.financeapp.R
import com.financeapp.data.models.Category
import com.financeapp.data.models.Transaction
import com.financeapp.data.models.TransactionType
import com.financeapp.databinding.ActivityAddTransactionBinding
import com.financeapp.ui.AppViewModelFactory
import com.financeapp.ui.TransactionViewModel
import com.financeapp.utils.DateUtils
import com.financeapp.utils.ValidationUtils
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch
import java.util.Calendar

class AddTransactionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTransactionBinding
    private val viewModel: TransactionViewModel by viewModels {
        AppViewModelFactory(application)
    }

    private var selectedType = TransactionType.EXPENSE
    private var selectedDate = System.currentTimeMillis()
    private var selectedCategoryId: Long = -1
    private var editingTransactionId: Long = -1
    private var categories = listOf<Category>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTransactionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        intent.getStringExtra("type")?.let {
            selectedType = TransactionType.valueOf(it)
        }
        editingTransactionId = intent.getLongExtra("transaction_id", -1L)

        setupTabs()
        setupDatePicker()
        setupSaveButton()

        if (editingTransactionId > 0L) {
            supportActionBar?.title = "Editar Registro"
            loadTransactionForEdit()
        } else {
            supportActionBar?.title = "Nuevo Registro"
        }
    }

    private fun setupTabs() {
        binding.tabType.addTab(binding.tabType.newTab().setText("Gasto"))
        binding.tabType.addTab(binding.tabType.newTab().setText("Ingreso"))

        if (selectedType == TransactionType.INCOME) {
            binding.tabType.selectTab(binding.tabType.getTabAt(1))
        }

        binding.tabType.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                selectedType = if (tab.position == 0) TransactionType.EXPENSE else TransactionType.INCOME
                updateCategorySpinner()
                updateColors()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        updateColors()
        updateCategorySpinner()
    }

    private fun updateColors() {
        val color = if (selectedType == TransactionType.EXPENSE)
            getColor(R.color.expense_red) else getColor(R.color.income_green)
        binding.toolbar.setBackgroundColor(color)
    }

    private fun updateCategorySpinner() {
        viewModel.getCategoriesByType(selectedType).observe(this) { cats ->
            categories = cats
            val names = cats.map { "${it.icon} ${it.name}" }
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.spinnerCategory.adapter = adapter

            if (selectedCategoryId > 0L) {
                val idx = cats.indexOfFirst { it.id == selectedCategoryId }
                if (idx >= 0) binding.spinnerCategory.setSelection(idx)
            }
        }
    }

    private fun setupDatePicker() {
        binding.btnSelectDate.text = DateUtils.formatDateFull(selectedDate)
        binding.btnSelectDate.setOnClickListener {
            val cal = Calendar.getInstance()
            cal.timeInMillis = selectedDate
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    val newCal = Calendar.getInstance()
                    newCal.set(year, month, day)
                    selectedDate = newCal.timeInMillis
                    binding.btnSelectDate.text = DateUtils.formatDateFull(selectedDate)
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener {
            if (validateForm()) saveTransaction()
        }
    }

    private fun validateForm(): Boolean {
        var valid = true
        val amountStr = binding.etAmount.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()

        if (!ValidationUtils.isValidAmount(amountStr)) {
            binding.tilAmount.error = "Ingresa un monto válido mayor a 0"
            valid = false
        } else {
            binding.tilAmount.error = null
        }

        if (description.isEmpty()) {
            binding.tilDescription.error = "La descripción es requerida"
            valid = false
        } else {
            binding.tilDescription.error = null
        }

        if (categories.isEmpty()) {
            Toast.makeText(this, "No hay categorías disponibles", Toast.LENGTH_SHORT).show()
            valid = false
        }

        return valid
    }

    private fun saveTransaction() {
        val amount = binding.etAmount.text.toString().toDouble()
        val description = binding.etDescription.text.toString().trim()
        val notes = binding.etNotes.text.toString().trim()
        val selectedPos = binding.spinnerCategory.selectedItemPosition
        if (selectedPos < 0 || selectedPos >= categories.size) {
            Toast.makeText(this, "Selecciona una categoría", Toast.LENGTH_SHORT).show()
            return
        }
        val category = categories[selectedPos]

        val transaction = Transaction(
            id = if (editingTransactionId > 0L) editingTransactionId else 0L,
            amount = amount,
            description = description,
            categoryId = category.id,
            type = selectedType,
            date = selectedDate,
            notes = notes
        )

        lifecycleScope.launch {
            if (editingTransactionId > 0L) {
                viewModel.update(transaction)
                Toast.makeText(this@AddTransactionActivity, "Registro actualizado", Toast.LENGTH_SHORT).show()
            } else {
                viewModel.insert(transaction)
                Toast.makeText(this@AddTransactionActivity, "Registro guardado", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }

    private fun loadTransactionForEdit() {
        lifecycleScope.launch {
            val transaction = viewModel.getById(editingTransactionId) ?: return@launch
            selectedType = transaction.type
            selectedDate = transaction.date
            selectedCategoryId = transaction.categoryId

            binding.etAmount.setText(transaction.amount.toString())
            binding.etDescription.setText(transaction.description)
            binding.etNotes.setText(transaction.notes)
            binding.btnSelectDate.text = DateUtils.formatDateFull(selectedDate)

            val tabIdx = if (transaction.type == TransactionType.EXPENSE) 0 else 1
            binding.tabType.selectTab(binding.tabType.getTabAt(tabIdx))
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
