package com.financeapp.utils

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

object CurrencyFormatter {
    private val formatter = NumberFormat.getCurrencyInstance(Locale("es", "CO"))

    fun format(amount: Double): String {
        return formatter.format(amount)
    }

    fun formatCompact(amount: Double): String {
        return when {
            amount >= 1_000_000 -> "${"%.1f".format(amount / 1_000_000)}M"
            amount >= 1_000 -> "${"%.1f".format(amount / 1_000)}K"
            else -> format(amount)
        }
    }
}

object DateUtils {
    private val displayFormat = SimpleDateFormat("dd MMM yyyy", Locale("es", "CO"))
    private val fullFormat = SimpleDateFormat("dd/MM/yyyy", Locale("es", "CO"))
    private val monthYearFormat = SimpleDateFormat("MMMM yyyy", Locale("es", "CO"))

    fun formatDate(timestamp: Long): String = displayFormat.format(Date(timestamp))
    fun formatDateFull(timestamp: Long): String = fullFormat.format(Date(timestamp))
    fun formatMonthYear(timestamp: Long): String = monthYearFormat.format(Date(timestamp))

    fun getStartOfDay(timestamp: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = timestamp
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun getEndOfDay(timestamp: Long): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = timestamp
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        return cal.timeInMillis
    }

    fun getStartOfMonth(year: Int = -1, month: Int = -1): Long {
        val cal = Calendar.getInstance()
        if (year >= 0) cal.set(Calendar.YEAR, year)
        if (month >= 0) cal.set(Calendar.MONTH, month)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun getEndOfMonth(year: Int = -1, month: Int = -1): Long {
        val cal = Calendar.getInstance()
        if (year >= 0) cal.set(Calendar.YEAR, year)
        if (month >= 0) cal.set(Calendar.MONTH, month)
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        return cal.timeInMillis
    }

    fun getStartOfYear(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_YEAR, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun getEndOfYear(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.MONTH, 11)
        cal.set(Calendar.DAY_OF_MONTH, 31)
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        return cal.timeInMillis
    }

    fun getCurrentYear(): Int = Calendar.getInstance().get(Calendar.YEAR)
    fun getCurrentMonth(): Int = Calendar.getInstance().get(Calendar.MONTH)

    fun addMonths(timestamp: Long, months: Int): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = timestamp
        cal.add(Calendar.MONTH, months)
        return cal.timeInMillis
    }

    fun getDaysDifference(from: Long, to: Long): Long {
        return (to - from) / (1000 * 60 * 60 * 24)
    }

    fun parseDate(dateString: String): Long? {
        return try {
            fullFormat.parse(dateString)?.time
        } catch (e: Exception) {
            null
        }
    }
}

object ValidationUtils {
    fun isValidAmount(amountStr: String): Boolean {
        return try {
            val amount = amountStr.toDouble()
            amount > 0
        } catch (e: NumberFormatException) {
            false
        }
    }

    fun isValidInterestRate(rateStr: String): Boolean {
        return try {
            val rate = rateStr.toDouble()
            rate >= 0 && rate <= 100
        } catch (e: NumberFormatException) {
            false
        }
    }

    fun isValidInstallments(numStr: String): Boolean {
        return try {
            val num = numStr.toInt()
            num > 0 && num <= 600
        } catch (e: NumberFormatException) {
            false
        }
    }
}
