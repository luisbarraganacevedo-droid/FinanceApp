package com.financeapp.ui.categories

import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.*
import com.financeapp.R
import com.financeapp.data.models.Category
import com.financeapp.data.models.TransactionType
import com.financeapp.databinding.ActivityManageCategoriesBinding
import com.financeapp.databinding.DialogAddCategoryBinding
import com.financeapp.databinding.ItemCategoryBinding
import com.financeapp.ui.AppViewModelFactory
import com.financeapp.ui.CategoryViewModel
import com.google.android.material.tabs.TabLayout

class ManageCategoriesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityManageCategoriesBinding
    private val viewModel: CategoryViewModel by viewModels { AppViewModelFactory(application) }
    private lateinit var adapter: CategoryManageAdapter
    private var currentType = TransactionType.EXPENSE

    private val colorOptions = listOf(
        "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7",
        "#DDA0DD", "#F0E68C", "#98FB98", "#87CEEB", "#D3D3D3",
        "#2ECC71", "#27AE60", "#3498DB", "#E74C3C", "#F39C12"
    )
    private val emojiOptions = listOf(
        "🍔", "🚗", "💡", "🏥", "📚", "🎮", "👕", "🏠", "💻", "📦",
        "💼", "💰", "📈", "🏪", "🎵", "✈️", "🏋️", "🎓", "🛍️", "🍕"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManageCategoriesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Gestionar Categorías"

        setupAdapter()
        setupTabs()
        setupFab()
    }

    private fun setupAdapter() {
        adapter = CategoryManageAdapter(
            onDelete = { category ->
                if (!category.isDefault) {
                    AlertDialog.Builder(this)
                        .setTitle("Eliminar categoría")
                        .setMessage("¿Eliminar '${category.name}'?")
                        .setPositiveButton("Eliminar") { _, _ -> viewModel.delete(category) }
                        .setNegativeButton("Cancelar", null)
                        .show()
                } else {
                    Toast.makeText(this, "No puedes eliminar categorías predeterminadas", Toast.LENGTH_SHORT).show()
                }
            },
            onEdit = { category -> showAddEditDialog(category) }
        )
        binding.recyclerCategories.layoutManager = LinearLayoutManager(this)
        binding.recyclerCategories.adapter = adapter
    }

    private fun setupTabs() {
        binding.tabCategoryType.addTab(binding.tabCategoryType.newTab().setText("Gastos"))
        binding.tabCategoryType.addTab(binding.tabCategoryType.newTab().setText("Ingresos"))
        binding.tabCategoryType.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                currentType = if (tab?.position == 0) TransactionType.EXPENSE else TransactionType.INCOME
                observeCategories()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
        observeCategories()
    }

    private fun observeCategories() {
        viewModel.getCategoriesByType(currentType).observe(this) { cats ->
            adapter.submitList(cats)
        }
    }

    private fun setupFab() {
        binding.fabAddCategory.setOnClickListener { showAddEditDialog(null) }
    }

    private fun showAddEditDialog(existing: Category?) {
        val dialogBinding = DialogAddCategoryBinding.inflate(layoutInflater)
        var selectedColor = existing?.color ?: colorOptions[0]
        var selectedIcon = existing?.icon ?: emojiOptions[0]

        existing?.let { dialogBinding.etCategoryName.setText(it.name) }

        try {
            dialogBinding.tvSelectedColor.setBackgroundColor(Color.parseColor(selectedColor))
        } catch (e: Exception) { /* ignore */ }
        dialogBinding.tvSelectedIcon.text = selectedIcon

        val colorAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, colorOptions)
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        dialogBinding.spinnerColor.adapter = colorAdapter
        dialogBinding.spinnerColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedColor = colorOptions[pos]
                try {
                    dialogBinding.tvSelectedColor.setBackgroundColor(Color.parseColor(selectedColor))
                } catch (e: Exception) { /* ignore */ }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val iconAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, emojiOptions)
        iconAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        dialogBinding.spinnerIcon.adapter = iconAdapter
        dialogBinding.spinnerIcon.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedIcon = emojiOptions[pos]
                dialogBinding.tvSelectedIcon.text = selectedIcon
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Nueva Categoría" else "Editar Categoría")
            .setView(dialogBinding.root)
            .setPositiveButton("Guardar") { _, _ ->
                val name = dialogBinding.etCategoryName.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "El nombre es requerido", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val category = Category(
                    id = existing?.id ?: 0,
                    name = name,
                    icon = selectedIcon,
                    color = selectedColor,
                    type = currentType
                )
                if (existing == null) viewModel.insert(category)
                else viewModel.update(category)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

class CategoryManageAdapter(
    private val onDelete: (Category) -> Unit,
    private val onEdit: (Category) -> Unit
) : ListAdapter<Category, CategoryManageAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemCategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemCategoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(category: Category) {
            binding.tvCategoryIcon.text = category.icon
            binding.tvCategoryName.text = category.name
            binding.tvCategoryDefault.visibility = if (category.isDefault) View.VISIBLE else View.GONE
            try {
                binding.tvCategoryIcon.setBackgroundColor(Color.parseColor(category.color))
            } catch (e: Exception) { /* ignore */ }
            binding.btnEdit.setOnClickListener { onEdit(category) }
            binding.btnDelete.setOnClickListener { onDelete(category) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Category>() {
        override fun areItemsTheSame(a: Category, b: Category) = a.id == b.id
        override fun areContentsTheSame(a: Category, b: Category) = a == b
    }
}
