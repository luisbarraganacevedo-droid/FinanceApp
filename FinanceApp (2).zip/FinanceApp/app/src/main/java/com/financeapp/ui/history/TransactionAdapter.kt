package com.financeapp.ui.history

import android.graphics.Color
import android.view.*
import android.widget.PopupMenu
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.financeapp.R
import com.financeapp.data.models.Category
import com.financeapp.data.models.Transaction
import com.financeapp.data.models.TransactionType
import com.financeapp.databinding.ItemTransactionBinding
import com.financeapp.utils.CurrencyFormatter
import com.financeapp.utils.DateUtils

class TransactionAdapter(
    private val onEdit: (Transaction) -> Unit,
    private val onDelete: (Transaction) -> Unit,
    private val getCategoryById: (Long) -> Category?
) : ListAdapter<Transaction, TransactionAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemTransactionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(transaction: Transaction) {
            val category = getCategoryById(transaction.categoryId)
            binding.tvDescription.text = transaction.description
            binding.tvDate.text = DateUtils.formatDate(transaction.date)
            binding.tvCategoryName.text = category?.name ?: "Sin categoría"
            binding.tvCategoryIcon.text = category?.icon ?: "📦"

            val amountText = CurrencyFormatter.format(transaction.amount)
            if (transaction.type == TransactionType.INCOME) {
                binding.tvAmount.text = "+$amountText"
                binding.tvAmount.setTextColor(binding.root.context.getColor(R.color.income_green))
                binding.viewTypeIndicator.setBackgroundColor(binding.root.context.getColor(R.color.income_green))
            } else {
                binding.tvAmount.text = "-$amountText"
                binding.tvAmount.setTextColor(binding.root.context.getColor(R.color.expense_red))
                binding.viewTypeIndicator.setBackgroundColor(binding.root.context.getColor(R.color.expense_red))
            }

            try {
                val color = Color.parseColor(category?.color ?: "#D3D3D3")
                binding.tvCategoryIcon.setBackgroundColor(color)
            } catch (e: Exception) { /* ignore */ }

            binding.root.setOnLongClickListener {
                showContextMenu(binding.root, transaction)
                true
            }

            binding.btnMore.setOnClickListener {
                showContextMenu(it, transaction)
            }
        }

        private fun showContextMenu(view: View, transaction: Transaction) {
            PopupMenu(view.context, view).apply {
                menuInflater.inflate(R.menu.transaction_context_menu, menu)
                setOnMenuItemClickListener { item ->
                    when (item.itemId) {
                        R.id.action_edit -> { onEdit(transaction); true }
                        R.id.action_delete -> { onDelete(transaction); true }
                        else -> false
                    }
                }
                show()
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Transaction>() {
        override fun areItemsTheSame(oldItem: Transaction, newItem: Transaction) =
            oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Transaction, newItem: Transaction) =
            oldItem == newItem
    }
}
