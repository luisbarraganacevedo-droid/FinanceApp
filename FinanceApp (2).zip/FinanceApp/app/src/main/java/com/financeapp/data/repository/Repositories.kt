package com.financeapp.data.repository

import androidx.lifecycle.LiveData
import com.financeapp.data.db.*
import com.financeapp.data.models.*

class TransactionRepository(private val dao: TransactionDao) {
    fun getAllTransactions(): LiveData<List<Transaction>> = dao.getAllTransactions()

    fun getFilteredTransactions(
        type: String? = null,
        categoryId: Long? = null,
        startDate: Long? = null,
        endDate: Long? = null
    ): LiveData<List<Transaction>> = dao.getFilteredTransactions(type, categoryId, startDate, endDate)

    fun getTransactionsByDateRange(startDate: Long, endDate: Long): LiveData<List<Transaction>> =
        dao.getTransactionsByDateRange(startDate, endDate)

    suspend fun insert(transaction: Transaction): Long = dao.insert(transaction)
    suspend fun update(transaction: Transaction) = dao.update(transaction)
    suspend fun delete(transaction: Transaction) = dao.delete(transaction)
    suspend fun getById(id: Long): Transaction? = dao.getTransactionById(id)
    suspend fun getTotalIncome(startDate: Long, endDate: Long): Double = dao.getTotalIncome(startDate, endDate) ?: 0.0
    suspend fun getTotalExpense(startDate: Long, endDate: Long): Double = dao.getTotalExpense(startDate, endDate) ?: 0.0
    suspend fun getExpensesByCategory(startDate: Long, endDate: Long): List<CategorySummary> =
        dao.getExpensesByCategory(startDate, endDate)
}

class CategoryRepository(private val dao: CategoryDao) {
    fun getAllCategories(): LiveData<List<Category>> = dao.getAllCategories()
    fun getCategoriesByType(type: TransactionType): LiveData<List<Category>> =
        dao.getCategoriesByType(type.name)

    suspend fun insert(category: Category): Long = dao.insert(category)
    suspend fun update(category: Category) = dao.update(category)
    suspend fun delete(category: Category) = dao.delete(category)
    suspend fun getById(id: Long): Category? = dao.getCategoryById(id)
    suspend fun getCount(): Int = dao.getCategoryCount()
}

class CreditRepository(private val creditDao: CreditDao, private val paymentDao: CreditPaymentDao) {
    fun getActiveCredits(): LiveData<List<Credit>> = creditDao.getActiveCredits()
    fun getAllCredits(): LiveData<List<Credit>> = creditDao.getAllCredits()
    fun getPaymentsForCredit(creditId: Long): LiveData<List<CreditPayment>> =
        paymentDao.getPaymentsForCredit(creditId)

    fun getUpcomingPayments(startDate: Long, endDate: Long): LiveData<List<CreditPayment>> =
        paymentDao.getUpcomingPayments(startDate, endDate)

    fun getAllPendingPayments(): LiveData<List<CreditPayment>> = paymentDao.getAllPendingPayments()

    suspend fun insertCreditWithPayments(credit: Credit, payments: List<CreditPayment>): Long {
        val creditId = creditDao.insert(credit)
        val paymentsWithId = payments.map { it.copy(creditId = creditId) }
        paymentDao.insertAll(paymentsWithId)
        return creditId
    }

    suspend fun insert(credit: Credit): Long = creditDao.insert(credit)
    suspend fun update(credit: Credit) = creditDao.update(credit)
    suspend fun delete(credit: Credit) {
        paymentDao.deletePaymentsForCredit(credit.id)
        creditDao.delete(credit)
    }

    suspend fun getCreditById(id: Long): Credit? = creditDao.getCreditById(id)
    suspend fun updatePayment(payment: CreditPayment) = paymentDao.update(payment)
    suspend fun getPaymentById(id: Long): CreditPayment? = paymentDao.getPaymentById(id)
    suspend fun getTotalCreditDebt(): Double = creditDao.getTotalCreditDebt() ?: 0.0
    suspend fun deletePaymentsForCredit(creditId: Long) = paymentDao.deletePaymentsForCredit(creditId)
    suspend fun insertPayments(payments: List<CreditPayment>) = paymentDao.insertAll(payments)
}
