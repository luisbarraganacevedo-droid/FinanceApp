package com.financeapp.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

enum class TransactionType { INCOME, EXPENSE }

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Double,
    val description: String,
    val categoryId: Long,
    val type: TransactionType,
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val icon: String,
    val color: String,
    val type: TransactionType,
    val isDefault: Boolean = false
)

@Entity(tableName = "credits")
data class Credit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val totalAmount: Double,
    val interestRate: Double,
    val startDate: Long,
    val numberOfInstallments: Int,
    val paymentDayOfMonth: Int,
    val notes: String = "",
    val isActive: Boolean = true
)

@Entity(tableName = "credit_payments")
data class CreditPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val creditId: Long,
    val installmentNumber: Int,
    val dueDate: Long,
    val amount: Double,
    val isPaid: Boolean = false,
    val paidDate: Long? = null
)

data class TransactionWithCategory(
    val transaction: Transaction,
    val category: Category?
)

data class CategorySummary(
    val categoryId: Long,
    val categoryName: String,
    val categoryColor: String,
    val categoryIcon: String,
    val totalAmount: Double,
    val transactionCount: Int
)

data class MonthSummary(
    val month: Int,
    val year: Int,
    val totalIncome: Double,
    val totalExpense: Double
)
